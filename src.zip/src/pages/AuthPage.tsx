import { useState, type FormEvent } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../auth/AuthContext'
import { Link, useNavigate } from '../lib/router'
import { Wordmark } from '../components/ui/Icon'
import { Input } from '../components/ui/Field'
import { Button } from '../components/ui/Button'

export function AuthPage({ mode }: { mode: 'login' | 'register' }) {
  const register = mode === 'register'
  const navigate = useNavigate()
  const { session, refreshProfile } = useAuth()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')

  async function submit(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError(''); setMessage('')
    try {
      if (register) {
        const { data, error: signUpError } = await supabase.auth.signUp({ email: email.trim(), password, options: { data: { display_name: name.trim() } } })
        if (signUpError) throw signUpError
        if (!data.session) { setMessage('Account created. Check your email to confirm your address, then sign in.'); return }
        await refreshProfile(name.trim()); navigate('/dashboard', { replace: true })
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({ email: email.trim(), password })
        if (signInError) throw signInError
        // AuthProvider restores session and creates the Roots profile.
        setMessage('Signed in. Opening your Roots workspace…')
        window.setTimeout(() => navigate('/dashboard', { replace: true }), 250)
      }
    } catch (err) { setError(err instanceof Error ? err.message : 'Authentication failed. Please try again.') }
    finally { setBusy(false) }
  }
  if (session) { navigate('/dashboard', { replace: true }); return null }
  return <main className="auth-page"><section className="auth-card">
    <Link to="/" className="auth-brand"><Wordmark size={24} /></Link>
    <p className="eyebrow">A family archive for voices and languages</p>
    <h1>{register ? 'Create your Roots account' : 'Welcome back'}</h1>
    <p className="muted">{register ? 'Start preserving the stories your family carries.' : 'Sign in to continue preserving your family stories.'}</p>
    <form className="stack" onSubmit={submit}>
      {register && <Input label="Your name" value={name} onChange={e => setName(e.target.value)} autoComplete="name" required minLength={2} />}
      <Input label="Email address" type="email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" required />
      <div className="stack stack--xs"><Input label="Password" type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} autoComplete={register ? 'new-password' : 'current-password'} minLength={8} required />
      <label className="auth-show"><input type="checkbox" checked={showPassword} onChange={e => setShowPassword(e.target.checked)} /> Show password</label></div>
      {error && <p className="field__error" role="alert">{error}</p>}
      {message && <p className="notice" role="status">{message}</p>}
      <Button type="submit" size="lg" loading={busy}>{register ? 'Create account' : 'Sign in'}</Button>
    </form>
    <p className="auth-switch">{register ? 'Already have an account?' : 'New to Roots?'} <Link className="link" to={register ? '/login' : '/register'}>{register ? 'Sign in' : 'Create an account'}</Link></p>
    <p className="muted small">Your account does not replace the storyteller’s permission to record or transcribe their story.</p>
  </section></main>
}
