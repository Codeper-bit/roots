import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import type { Session, User } from '@supabase/supabase-js'
import { supabase } from '../lib/supabase'
import { clearUserId, setUserId } from '../lib/identity'
import { API_BASE_URL } from '../api/client'

interface AuthContextValue { session: Session | null; user: User | null; profileId: string | null; loading: boolean; signOut: () => Promise<void>; refreshProfile: (displayName?: string) => Promise<string> }
const AuthContext = createContext<AuthContextValue | null>(null)

async function syncProfile(session: Session, displayName?: string): Promise<string> {
  const response = await fetch(`${API_BASE_URL}/auth/profile`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json', Authorization: `Bearer ${session.access_token}` },
    body: JSON.stringify({ display_name: displayName || session.user.user_metadata?.display_name || session.user.email?.split('@')[0] || 'Roots user' }),
  })
  const payload = await response.json().catch(() => null)
  if (!response.ok) throw new Error(payload?.detail || `Could not create Roots profile (${response.status}).`)
  return payload.id as string
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [profileId, setProfileId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let alive = true
    supabase.auth.getSession().then(async ({ data, error }) => {
      if (error) console.error('Could not restore Supabase session', error.message)
      if (!alive) return
      setSession(data.session)
      if (data.session) {
        try { const id = await syncProfile(data.session); if (alive) { setProfileId(id); setUserId(id) } }
        catch (err) { console.error('Roots profile sync failed', err) }
      }
      if (alive) setLoading(false)
    })
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession)
      if (!nextSession) { setProfileId(null); clearUserId(); setLoading(false) }
      else {
        // Defer network work outside Supabase's auth event callback.
        queueMicrotask(() => { void syncProfile(nextSession).then(id => { setProfileId(id); setUserId(id) }).catch(err => console.error('Roots profile sync failed', err)).finally(() => setLoading(false)) })
      }
    })
    return () => { alive = false; listener.subscription.unsubscribe() }
  }, [])

  const value = useMemo<AuthContextValue>(() => ({
    session, user: session?.user ?? null, profileId, loading,
    signOut: async () => { const { error } = await supabase.auth.signOut(); if (error) throw error; setSession(null); setProfileId(null); clearUserId() },
    refreshProfile: async (displayName?: string) => { if (!session) throw new Error('Sign in first.'); const id = await syncProfile(session, displayName); setProfileId(id); setUserId(id); return id },
  }), [session, profileId, loading])
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
export function useAuth() { const value = useContext(AuthContext); if (!value) throw new Error('useAuth must be used inside AuthProvider'); return value }
